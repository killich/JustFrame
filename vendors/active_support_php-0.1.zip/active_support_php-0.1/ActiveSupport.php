<?php

/*
 * ActiveSupport PHP
 *
 * (c) 2007 Ben Vinegar (http://www.benlog.org)
 */

class ActiveSupport 
{

  static function get($native) 
  {
    if (is_integer($native))
      return new ActiveSupport_Integer($native);

    else if (is_numeric($native))
      return new ActiveSupport_Numeric($native);

    else if (is_string($native))
      return new ActiveSupport_String($native);
    
    else if (is_array($native))
      return new ActiveSupport_Array($native);

    else
      throw new Exception("Unknown type");
  }
}

/*
 * ActiveSupport_Object
 */

class ActiveSupport_Object 
{

  protected $native;

  public function __construct($value) 
  {
    $this->native = $value;
  }

  public function __call($func, $args) 
  {
    $real_func_name = preg_replace('/_$/', '', $func);

    if (!method_exists($this, $real_func_name))
      throw new Exception();
    
    $native = call_user_func_array(array($this, $real_func_name), $args);
    return new ActiveSupport_Numeric($native);
  }

  public function toNative() 
  {
    return $this->native;
  }
}

/*
 * ActiveSupport_Numeric
 */

class ActiveSupport_Numeric extends ActiveSupport_Object
{
  
  //-------------------------------------------------------
  // ActiveSupport::CoreExtensions::Numeric::Time
  //=======================================================

  public function ago($time = null) 
  {
    if (!$time) $time = time();
    return $time - $this->native;
  }
  
  public function until($time) 
  {
    return $this->ago($time);
  }

  public function since($time) 
  {
    return $time + $this->native;
  }

  public function fromNow($time) 
  {
    return $this->since($time);
  }

  public function seconds() 
  {
    return $this->native;
  }

  public function minutes() 
  { 
    return $this->native * 60;
  }

  public function minute() 
  {
    return $this->minutes();
  }

  public function hours() 
  {
    return $this->native * 60 * 60;
  }

  public function hour() 
  {
    return $this->hours();
  }

  public function days() 
  {
    return $this->native * 60 * 60 * 24;
  }

  public function day() 
  {
    return $this->days();
  }

  public function weeks() 
  {
    return $this->native * 60 * 60 * 24 * 7;
  }

  public function week() 
  {
    return $this->weeks();
  }

  public function fortnights() 
  {
    return $this->native * 60 * 60 * 24 * 14;
  }

  public function fortnight() 
  {
    return $this->fortnights();
  }

  public function months() 
  {
    return $this->native * 60 * 60 * 24 * 30;
  }

  public function month() 
  {
    return $this->months();
  }

  public function years() 
  {
    return (int)($this->native * ActiveSupport::numeric(365.25)->days);
  }

  public function year() 
  {
    return $this->years();
  }

  //-------------------------------------------------------
  // ActiveSupport::CoreExtensions::Numeric::Bytes
  //=======================================================

  public function bytes() 
  {
    return $this;
  }

  public function byte() 
  {
    return $this->bytes();
  }

  public function kilobytes() 
  {
    return $this->native * 1024;
  }

  public function kilbyte() 
  {
    return $this->kilobytes();
  }

  public function megabytes() 
  {
    return $this->native * (1024  ^ 2);
  }

  public function megabyte() 
  {
    return $this->megabytes();
  }

  public function gigabytes() 
  {
    return $this->native * (1024 ^ 3);
  }

  public function gigabyte() 
  {
    return $this->gigabytes();
  }

  public function terabytes() 
  {
    return $this->native * (1024 ^ 4);
  }

  public function terabyte() 
  {
    return $this->terabytes();
  }

  public function petabytes() 
  {
    return $this->native * (1024 ^ 5);
  }

  public function petabyte() 
  {
    return $this->petabytes();
  }

  public function exabytes() 
  {
    return $this->native * (1024 ^ 6);
  }
  
  public function exabyte() 
  {
    return $this->exabytes();
  }
}

/*
 * ActiveSupport_Integer
 */

class ActiveSupport_Integer extends ActiveSupport_Numeric {

  //-------------------------------------------------------
  // ActiveSupport::CoreExtensions::Integer::EvenOdd
  //=======================================================

  public function ordinalize() 
  {
    return ActiveSupport_Inflector::ordinalize($this->native);
  }

  public function isMultipleOf($num) 
  {
    return $this->native % num == 0;
  }

  public function isEven() 
  {
    return $this->is_multiple_of(2);
  }

  public function isOdd() 
  {
    return !$this->is_even();
  }
}

/*
 * ActiveSupport_Inflector
 */

class ActiveSupport_Inflector 
{

  static public function ordinalize($number) 
  {
    $p = $number % 100;

    if ($p == 11 || $p == 12 || $p == 13) {
      return $number . "th";
    } else {
      $t = $number % 10;
      switch ($t) {
        case 1:  return $number . "st";
        case 2:  return $number . "nd";
        case 3:  return $number . "rd";
        default: return $number . "th";
      }
    }
  }
}

/*
 * ActiveSupport_Array
 */
class ActiveSupport_Array extends ActiveSupport_Object 
{
  // TODO
}

/*
 * ActiveSupport_String
 */

class ActiveSupport_String extends ActiveSupport_Object 
{
  public function endsWith($string) {
    return preg_match("/$string$/", $this->native);
  }
}

/*
 * ActiveSupport_String
 */

class ActiveSupport_Time extends ActiveSupport_Object
{
  public static function daysInMonth($month, $year = null)
  {
    if ($month == 2)
      return !($year == null) && ($year % 4 == 0) && (($year % 100 != 0) || ($year % 400 == 0)) ? 29 : 28;
    else if ($month <= 7)
      return $month % 2 == 0 ? 30 : 31;
    else
      return $month % 2 == 0 ? 31 : 30;
  }
}


/*
 * ActiveSupport Shotcut
 */

function _($native) 
{
  return ActiveSupport::get($native);
}
?>
